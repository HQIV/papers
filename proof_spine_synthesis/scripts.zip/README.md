Run from repo root:

  python3 scripts/hqiv_proof_spine_synthesis_export.py
