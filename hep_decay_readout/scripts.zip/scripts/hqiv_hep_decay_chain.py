#!/usr/bin/env python3
"""
HQIV HEP decay-chain calculator — CERN / beam-target kinematics layer.

Extends ``hqiv_decay_chain`` with:

* **Collision setup:** beam species + kinetic energy vs target species + energy
* **Environment:** magnetic field (weak-bridge dressing), lab temperature, gravity stack
* **Particle registry:** HQIV-derived masses from hadron catalog + TUFT excitations
* **Decay topology:** CERN-accessible daughter maps (strong / weak / EM slots)
* **Chain expansion:** production gate from ``sqrt(s)`` then multi-step decays

Masses and widths use HQIV readouts only (constituent + composite trace / TUFT).
Published PDG masses are never used as prediction inputs.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import math
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import hqiv_decay_chain as dc
import hqiv_hep_decay_readout as hdr
import hqiv_hep_decay_sigma as hsig
import hqiv_hep_multichannel_expansion as mc
import hqiv_hep_patch_species as hps
import hqiv_hep_production_readout as hpr
import hqiv_lean_physics_primitives as lean
import hqiv_mass_calculator_core as hmc
import hqiv_nuclear_outside_temperature_dynamics as notd
import hqiv_scale_witness as sw
import hqiv_tuft_global_hadron_readout as tuft
import hqiv_weak_fano_hopf_bridge as weak_bridge

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_JSON = ROOT / "data" / "hep_decay_chain_readout.json"

HBAR_MEV_S = 6.582119569e-22  # Lean SpinStatistics.hbar_MeV_s scale

# Fine-structure coupling for EM quarkonium slots (continuum comparison layer; not HQIV α=3/5).
_EM_FINE_STRUCTURE_ALPHA = 1.0 / 137.036

HepChannelTag = Literal["strong", "weak", "electromagnetic", "weak_hadron", "stable"]

# Stable species only — all decaying hadrons are enumerated in
# ``hqiv_hep_multichannel_expansion`` from patch-ledger rules.
# Comparison catalog ids (``config_id``) are nominal aliases via ``hqiv_hep_patch_species``.
STABLE_SPECIES = frozenset({"p", "gamma", "e_plus", "e_minus"})

# Beam / target species for collider presets (catalog id or special).
BEAM_SPECIES: dict[str, str] = {
    "p": "p",
    "proton": "p",
    "Pb": "Pb208",
    "pb": "Pb208",
    "e-": "e-",
    "e+": "e+",
    "e_plus": "e+",
    "e_minus": "e-",
    "pi+": "pi_plus",
    "pi-": "pi_minus",
    "K+": "K_plus",
    "K-": "K_minus",
    "K0_bar": "K0",
    "D+": "D_plus",
    "D0": "D0",
    "Ds+": "Ds_plus",
    "B+": "B_plus",
    "B0": "B0",
    "J/psi": "Jpsi",
    "Upsilon": "Upsilon",
    "mu-": "mu_minus",
    "mu+": "mu_plus",
    "d": "deuteron",
    "D": "deuteron",
}

# Lean `hadronIntrinsicScale_meson` squared — chiral projection of TUFT meson ground.
CHIRAL_PSEUDOSCALAR_FACTOR = hdr.CHIRAL_PSEUDOSCALAR_FACTOR

# Lean `pionDecayConstantRatio` = √(4/9) = 2/3.
HADRON_INTRINSIC_SCALE_MESON = (2.0 / 3.0) ** 2  # 4/9
PION_DECAY_CONSTANT_RATIO = hdr.PION_DECAY_CONSTANT_RATIO


def _chiral_pseudoscalar_mass_mev(species_id: str, *, xi: float) -> float | None:
    """Light π/K/η from TUFT meson(0,0) with HadronMassReadout chiral projection."""
    sid = BEAM_SPECIES.get(species_id, species_id)
    if sid in ("pi_plus", "pi_minus", "pi_zero"):
        ch = tuft.TuftExcitationChannel.meson(0, 0, pdg_key="pi")
        base = tuft.tuft_excited_mass_global_at_xi_mev(xi, ch)
        return base * CHIRAL_PSEUDOSCALAR_FACTOR
    if sid in ("K_plus", "K_minus", "K0", "K0_bar"):
        ch = tuft.TuftExcitationChannel.meson(0, 0, n_strange=1, pdg_key="K")
        base = tuft.tuft_excited_mass_global_at_xi_mev(xi, ch)
        m_pi = base * CHIRAL_PSEUDOSCALAR_FACTOR
        w = tuft.MESON_LIGHT_EXCITATION_WEIGHT
        # One valence strange: gap from π with second-order shell detuning (Lean γ at ℓ+1=4).
        strangeness_lift = m_pi * (1.0 / w - 1.0) * (1.0 + lean.GAMMA / 8.0)
        return (m_pi + strangeness_lift) * hdr.chiral_pseudoscalar_outside_mass_dressing()
    if sid == "eta":
        ch = tuft.TuftExcitationChannel.meson(0, 0, isoscalar=True, pdg_key="eta")
        base = tuft.tuft_excited_mass_global_at_xi_mev(xi, ch)
        w = tuft.tuft_content_excitation_weight(ch)
        return base * CHIRAL_PSEUDOSCALAR_FACTOR / w
    return None


# Special non-catalog masses (MeV) from HQIV witnesses / lepton sector.
SPECIAL_MASSES_MEV: dict[str, float] = {
    "e-": 0.5109989461,
    "e+": 0.5109989461,
    "mu_plus": 105.6583755,
    "mu_minus": 105.6583755,
    "mu+": 105.6583755,
    "mu-": 105.6583755,
    "gamma": 0.0,
    "deuteron": 1875.612,  # approximate from dynamic beta chart scale
    "Pb208": 193.682 * 208.0,  # constituent proxy: nucleon mass × A
}


@dataclass(frozen=True)
class ExperimentEnvironment:
    """Laboratory environment dressing (Lean: NeutronLifetimeMethod + outside support)."""

    magnetic_field_tesla: float = 0.0
    collider_reference_tesla: float = 4.0
    comoving_stream_fraction: float = 0.0
    lab_temperature_K: float = 293.15
    gravity_tier: notd.GravityBindingTier = "earth"
    trap_embedding: bool = False
    molecular_host: str | None = None

    def weak_width_factor(self) -> float:
        if self.trap_embedding:
            return weak_bridge.weak_bridge_shape()  # baseline; full trap uses B
        b = max(self.magnetic_field_tesla, 0.0)
        rho = min(1.0, b / 1.0)  # ucnTrapReferenceFieldTesla = 1
        trap_like = 1.0 + lean.GAMMA * rho * weak_bridge.weak_bridge_shape()
        collider = hdr.collider_curvature_width_factor(
            b,
            max(self.collider_reference_tesla, 1e-9),
            self.comoving_stream_fraction,
            weak_bridge_shape=weak_bridge.weak_bridge_shape(),
        )
        return trap_like * collider

    def outside_support_factor(self) -> float:
        phi = notd.local_outside_phi_epsilon(
            self.gravity_tier,
            molecular_host=self.molecular_host,
        )
        return notd.lab_outside_support_lifetime_factor(
            self.lab_temperature_K,
            phi_gravity_epsilon=phi,
        )


@dataclass(frozen=True)
class BeamComponent:
    """One beam species with kinetic energy and composition fraction."""

    species_id: str
    kinetic_energy_gev: float
    fraction: float = 1.0


def parse_beam_mix(spec: str, *, default_energy_gev: float) -> tuple[BeamComponent, ...]:
    """
    Parse ``p:0.7,pi+:12@0.3`` — optional ``@energy`` GeV per species.

    Fractions are renormalized if they do not sum to 1.
    """
    parts = [p.strip() for p in spec.split(",") if p.strip()]
    if not parts:
        return ()
    out: list[BeamComponent] = []
    for part in parts:
        if "@" in part:
            left, energy_s = part.rsplit("@", 1)
            energy = float(energy_s)
        else:
            left = part
            energy = default_energy_gev
        if ":" in left:
            sid, frac_s = left.split(":", 1)
            frac = float(frac_s)
        else:
            sid, frac = left, 1.0
        sid = BEAM_SPECIES.get(sid.strip(), sid.strip())
        out.append(BeamComponent(sid, energy, frac))
    total = sum(c.fraction for c in out)
    if total <= 0.0:
        raise ValueError(f"beam mix fractions must be positive: {spec!r}")
    if abs(total - 1.0) > 1e-9:
        out = [
            BeamComponent(c.species_id, c.kinetic_energy_gev, c.fraction / total)
            for c in out
        ]
    return tuple(out)


@dataclass(frozen=True)
class BeamTargetSetup:
    """
    Beam (partial) at kinetic energy vs target species.

    ``beam_fraction`` scales effective luminosity / composition (0–1).
    ``collision_mode``:
      - ``head_on``: opposite collinear beams (LHC, SPS collider)
      - ``fixed_target``: target at rest in lab (SPS/PS on fixed target)
    """

    beam_id: str
    beam_kinetic_energy_gev: float
    target_id: str
    target_kinetic_energy_gev: float = 0.0
    beam_fraction: float = 1.0
    collision_mode: str = "auto"
    beam_mix: tuple[BeamComponent, ...] = ()

    def resolve_beam(self) -> str:
        return BEAM_SPECIES.get(self.beam_id, self.beam_id)

    def resolve_target(self) -> str:
        return BEAM_SPECIES.get(self.target_id, self.target_id)

    def resolved_collision_mode(self) -> str:
        if self.collision_mode != "auto":
            return self.collision_mode
        beam = self.resolve_beam()
        target = self.resolve_target()
        if beam in ("e+", "e-") and target in ("e+", "e-"):
            return "ee"
        if self.target_kinetic_energy_gev <= 0.0:
            return "fixed_target"
        return "head_on"


@dataclass(frozen=True)
class CollisionKinematics:
    sqrt_s_gev: float
    s_gev2: float
    xi_collision: float
    beam_id: str
    target_id: str
    beam_kinetic_gev: float
    target_kinetic_gev: float
    cm_energy_gev: float
    beta_beam: float
    beta_target: float

    @property
    def accessible_mass_gev(self) -> float:
        """Conservative CM production ceiling (full √s for e⁺e⁻ resonances)."""
        if self.beam_id in ("e+", "e-") and self.target_id in ("e+", "e-"):
            return self.sqrt_s_gev
        return 0.5 * self.sqrt_s_gev * 0.98


@dataclass(frozen=True)
class HepParticle:
    species_id: str
    label: str
    mass_mev: float
    xi: float
    structure: str
    pdg_name: str
    cern_accessible: bool
    tuft_channel: tuft.TuftExcitationChannel | None = None

    @property
    def mass_gev(self) -> float:
        return self.mass_mev / 1000.0


@dataclass(frozen=True)
class HepDecayMode:
    parent_id: str
    channel: HepChannelTag
    daughter_ids: tuple[str, ...]
    relative_branch: float

    @property
    def key(self) -> str:
        d = "+".join(self.daughter_ids) if self.daughter_ids else "stable"
        return f"{self.parent_id}->{d}"


@dataclass(frozen=True)
class HepDecayEdge:
    parent: HepParticle
    daughters: tuple[HepParticle, ...]
    mode: HepDecayMode
    q_mev: float
    width_per_s: float
    half_life_s: float
    branching_ratio: float
    channel_open: bool
    emitted: tuple[str, ...]


@dataclass
class HepDecayNode:
    particle: HepParticle
    depth: int
    cumulative_weight: float
    cumulative_time_s: float
    via: HepDecayEdge | None = None
    children: list[HepDecayNode] = field(default_factory=list)


@dataclass(frozen=True)
class HepDecayChainResult:
    setup: BeamTargetSetup
    kinematics: CollisionKinematics
    environment: ExperimentEnvironment
    produced: tuple[HepParticle, ...]
    root_nodes: tuple[HepDecayNode, ...]
    all_nodes: tuple[HepDecayNode, ...]
    terminal: tuple[HepDecayNode, ...]
    production_rates: tuple[hpr.ProductionRate, ...] = ()


def _tuft_channel_for_species(species_id: str) -> tuft.TuftExcitationChannel | None:
    mapping: dict[str, tuft.TuftExcitationChannel] = {
        "p": tuft.TuftExcitationChannel.baryon(0, 0, pdg_key="proton"),
        "delta_p": tuft.TuftExcitationChannel.baryon(0, 1, pdg_key="Delta(1232)"),
        "delta_pp": tuft.TuftExcitationChannel.baryon(0, 1, pdg_key="Delta(1232)"),
        "delta_0": tuft.TuftExcitationChannel.baryon(0, 1, pdg_key="Delta(1232)"),
        "delta_m": tuft.TuftExcitationChannel.baryon(0, 1, pdg_key="Delta(1232)"),
        "rho_plus": tuft.TuftExcitationChannel.meson(0, 1, 0, "rho"),
        "rho_zero": tuft.TuftExcitationChannel.meson(0, 1, 0, "rho"),
        "omega_meson": tuft.TuftExcitationChannel.meson(0, 1, 0, "omega", isoscalar=True),
        "phi": tuft.TuftExcitationChannel.meson(1, 0, 2, "phi(1020)"),
        "K_star": tuft.TuftExcitationChannel.meson(1, 0, 1, "K*(892)"),
    }
    return mapping.get(species_id)


@lru_cache(maxsize=1)
def _catalog_index() -> dict[str, dict[str, Any]]:
    rows = hmc.parse_hadron_catalog()
    return {r["config_id"]: r for r in rows}


@lru_cache(maxsize=4)
def _mass_stack() -> tuple[hmc.CoherenceReport, sw.WitnessBundle, dict[str, float]]:
    report = hmc.run_coupling_stack("proton_lockin")
    bundle = sw.load_witness_bundle()
    qm = hmc.derived_quark_gev()
    return report, bundle, qm


# Baryon octet / decuplet species handled by strangeness-gap readout (not broken composite trace).
STRANGE_BARYON_IDS = frozenset(
    {
        "lambda",
        "sigma_plus",
        "sigma_zero",
        "sigma_minus",
        "xi_zero",
        "xi_minus",
        "omega",
        "sigma_star_p",
        "sigma_star_0",
        "sigma_star_m",
    }
)

# Charm / bottom catalog entries use quark-ladder gap readout (not witness-scaled composite trace).
HEAVY_FLAVOR_SPECIES = frozenset(
    {
        "D_plus",
        "D0",
        "Ds_plus",
        "Jpsi",
        "lambda_c",
        "sigma_c",
        "xi_c",
        "omega_c",
        "B_plus",
        "B0",
        "Bs",
        "Upsilon",
        "lambda_b",
        "sigma_b",
        "xi_b",
        "omega_b",
    }
)

HEAVY_MESON_SPECIES = frozenset(
    {"D_plus", "D0", "Ds_plus", "Jpsi", "B_plus", "B0", "Bs", "Upsilon"}
)
HEAVY_BARYON_SPECIES = frozenset(
    {"lambda_c", "sigma_c", "xi_c", "omega_c", "lambda_b", "sigma_b", "xi_b", "omega_b"}
)
HIDDEN_QUARKONIUM = frozenset({"Jpsi", "Upsilon"})
OPEN_CHARM_MESONS = frozenset({"D_plus", "D0", "Ds_plus"})
OPEN_BOTTOM_MESONS = frozenset({"B_plus", "B0", "Bs"})
CHARMED_BARYONS = frozenset({"lambda_c", "sigma_c", "xi_c", "omega_c"})
BOTTOM_BARYONS = frozenset({"lambda_b", "sigma_b", "xi_b", "omega_b"})


def _valence_flavor_counts(species_id: str) -> dict[str, int]:
    """Count valence quark + antiquark flavors on a catalog entry."""
    sid = BEAM_SPECIES.get(species_id, species_id)
    cat = _catalog_index().get(sid)
    if cat is None:
        return {}
    counts = {f: 0 for f in ("u", "d", "s", "c", "b", "t")}
    for flavor, role in cat.get("valence") or []:
        if role in ("quark", "antiquark") and flavor in counts:
            counts[flavor] += 1
    return counts


def _heavy_gap_fraction(n_heavy: int) -> float:
    return hdr.heavy_flavor_gap_fraction(n_heavy)


def _heavy_flavor_mass_mev(species_id: str, *, xi: float) -> float | None:
    """
    Charm / bottom hadron masses from `HepDecayReadout.lean` quark-ladder gaps.
    """
    sid = BEAM_SPECIES.get(species_id, species_id)
    if sid not in HEAVY_FLAVOR_SPECIES:
        return None
    m_pi = _chiral_pseudoscalar_mass_mev("pi_plus", xi=xi)
    m_k = _chiral_pseudoscalar_mass_mev("K_plus", xi=xi)
    if m_pi is None or m_k is None:
        raise ValueError("chiral π/K readout required for heavy-flavour mass")
    m_p = _witness_nucleon_mass_mev("p")
    kind_map: dict[str, tuple[str, dict[str, int]]] = {
        "D_plus": ("open_charm", {"n_charm": 1, "n_strange": 0}),
        "D0": ("open_charm", {"n_charm": 1, "n_strange": 0}),
        "Ds_plus": ("open_charm_strange", {"n_charm": 1, "n_strange": 1}),
        "Jpsi": ("hidden_charm", {"n_charm": 2, "n_strange": 0}),
        "B_plus": ("open_bottom", {"n_charm": 0, "n_strange": 0}),
        "B0": ("open_bottom", {"n_charm": 0, "n_strange": 0}),
        "Bs": ("open_bottom_strange", {"n_charm": 0, "n_strange": 1}),
        "Upsilon": ("hidden_bottom", {"n_charm": 0, "n_strange": 0}),
    }
    if sid in kind_map:
        kind, kw = kind_map[sid]
        return hdr.heavy_species_mass_mev(
            kind,  # type: ignore[arg-type]
            m_pi_mev=m_pi,
            m_k_mev=m_k,
            m_proton_mev=m_p,
            **kw,
        )
    counts = _valence_flavor_counts(sid)
    if sid in CHARMED_BARYONS or sid in ("xi_cc_plus", "xi_cc_plus_plus", "omega_cc"):
        mult = hdr.CHARMED_BARYON_MULTIPLET_BY_SPECIES.get(sid)
        n_charm = counts.get("c", 0)
        if mult is not None and n_charm > 0:
            return hdr.charmed_baryon_multiplet_mass_mev(
                m_p, m_k, m_pi, mult, n_charm=n_charm
            )
        return hdr.heavy_species_mass_mev(
            "charmed_baryon",
            m_pi_mev=m_pi,
            m_k_mev=m_k,
            m_proton_mev=m_p,
            n_charm=n_charm,
            n_strange=counts.get("s", 0),
        )
    if sid in BOTTOM_BARYONS:
        mult = hdr.BOTTOM_BARYON_MULTIPLET_BY_SPECIES.get(sid)
        if mult is None:
            n_strange = counts.get("s", 0)
            mult = "lambda" if n_strange <= 0 else "xi" if n_strange == 1 else "omega"
        return hdr.heavy_species_mass_mev(
            "bottom_baryon",
            m_pi_mev=m_pi,
            m_k_mev=m_k,
            m_proton_mev=m_p,
            n_charm=counts.get("c", 0),
            n_strange=counts.get("s", 0),
            multiplet=mult,
        )
    return None


def _witness_nucleon_mass_mev(species_id: str) -> float:
    _, bundle, _ = _mass_stack()
    if species_id == "n":
        return bundle.derived_neutron_mass_mev
    return bundle.derived_proton_mass_mev


def _strange_quark_count(species_id: str) -> int | None:
    cat = _catalog_index().get(species_id)
    if cat is None:
        return None
    valence = cat.get("valence") or []
    return sum(
        1
        for v in valence
        if (v[0] if isinstance(v, tuple) else v.get("flavor")) == "s"
        and (v[1] if isinstance(v, tuple) else v.get("role")) == "quark"
    )


def _strange_baryon_mass_mev(species_id: str, *, xi: float) -> float | None:
    """
    Octet/decuplet baryons from nucleon witness + HQIV chiral strangeness gap (K−π).

    Lean alignment: ``HadronMassReadout`` meson chiral weight + ``TuftGlobalHadronReadout`` gap;
    per-strange lift uses α=3/5 via ``GAMMA`` second-order shell opening.
    """
    sid = BEAM_SPECIES.get(species_id, species_id)
    if sid not in STRANGE_BARYON_IDS:
        return None
    n_s = _strange_quark_count(sid)
    if n_s is None or n_s <= 0:
        return None
    m_p = _witness_nucleon_mass_mev("p")
    m_pi = _chiral_pseudoscalar_mass_mev("pi_plus", xi=xi)
    m_k = _chiral_pseudoscalar_mass_mev("K_plus", xi=xi)
    if m_pi is None or m_k is None:
        raise ValueError("chiral π/K readout required for strange baryon mass")
    decuplet = sid.startswith("sigma_star") or sid in ("delta_p", "delta_pp", "delta_0", "delta_m")
    return hdr.strange_baryon_mass_mev(m_p, m_k, m_pi, n_s, decuplet=decuplet)


_MASS_OVERRIDE: dict[str, float] | None = None


@contextlib.contextmanager
def mass_override_context(overrides: dict[str, float] | None):
    """Temporary mass overrides for Monte Carlo σ propagation."""
    global _MASS_OVERRIDE
    previous = _MASS_OVERRIDE
    _MASS_OVERRIDE = dict(overrides) if overrides else None
    try:
        yield
    finally:
        _MASS_OVERRIDE = previous


def particle_mass_mev(species_id: str, *, xi: float = lean.XI_LOCKIN) -> float:
    """HQIV mass readout for a catalog or special species."""
    sid = hps.resolve_species_alias(species_id)
    sid = BEAM_SPECIES.get(sid, sid)
    if _MASS_OVERRIDE is not None and sid in _MASS_OVERRIDE:
        return _MASS_OVERRIDE[sid]
    if sid in SPECIAL_MASSES_MEV:
        return SPECIAL_MASSES_MEV[sid]

    chiral = _chiral_pseudoscalar_mass_mev(sid, xi=xi)
    if chiral is not None:
        return chiral

    strange = _strange_baryon_mass_mev(sid, xi=xi)
    if strange is not None:
        return strange

    heavy = _heavy_flavor_mass_mev(sid, xi=xi)
    if heavy is not None:
        return heavy

    ch = _tuft_channel_for_species(sid)
    if ch is not None:
        mass = tuft.tuft_excited_mass_global_at_xi_mev(xi, ch)
        if sid == "phi":
            mass *= hdr.hidden_strangeness_vector_outside_mass_dressing()
        return mass

    cat = _catalog_index()
    if sid not in cat:
        raise KeyError(f"unknown species {species_id!r}")
    report, bundle, qm = _mass_stack()
    result = hmc.hadron_mass_from_stack(cat[sid], report=report, bundle=bundle, qm=qm)
    return result.m_mev


def build_particle(
    species_id: str,
    *,
    xi: float = lean.XI_LOCKIN,
    cern_accessible: bool = True,
) -> HepParticle:
    sid = hps.resolve_species_alias(species_id)
    sid = BEAM_SPECIES.get(sid, sid)
    patch = hps.patch_from_species_id(sid)
    if patch is not None:
        return build_particle_from_patch(
            patch,
            xi=xi,
            cern_accessible=cern_accessible,
            species_id=sid,
        )
    mass = particle_mass_mev(sid, xi=xi)
    ch = _tuft_channel_for_species(sid)
    cat = _catalog_index().get(sid, {})
    return HepParticle(
        species_id=sid,
        label=cat.get("label", sid),
        mass_mev=mass,
        xi=xi,
        structure=cat.get("structure", "special"),
        pdg_name=cat.get("pdgName", sid),
        cern_accessible=cern_accessible,
        tuft_channel=ch,
    )


def build_particle_from_patch(
    patch: hps.HadronPatch | None,
    *,
    xi: float = lean.XI_LOCKIN,
    cern_accessible: bool = True,
    species_id: str | None = None,
) -> HepParticle:
    """Build a decay-chain particle from a property patch (nominal id is readout alias only)."""
    if patch is None:
        raise KeyError(f"unknown species patch for {species_id!r}")
    sid = species_id or patch.nominal_id
    if not sid:
        raise ValueError("patch requires nominal_id or explicit species_id for mass readout")
    mass = particle_mass_mev(sid, xi=xi)
    ch = _tuft_channel_for_species(sid)
    cat = _catalog_index().get(sid, {})
    return HepParticle(
        species_id=sid,
        label=cat.get("label", sid),
        mass_mev=mass,
        xi=xi,
        structure=cat.get("structure", "special"),
        pdg_name=cat.get("pdgName", sid),
        cern_accessible=cern_accessible,
        tuft_channel=ch,
    )


def collision_kinematics(setup: BeamTargetSetup) -> CollisionKinematics:
    """Mandelstam s for collinear beam + target (mixtures use fraction-weighted s)."""
    if setup.beam_mix:
        s_weighted = 0.0
        beam_id = setup.beam_mix[0].species_id
        target_id = setup.resolve_target()
        beam_e = setup.beam_mix[0].kinetic_energy_gev
        target_e = setup.target_kinetic_energy_gev
        for comp in setup.beam_mix:
            sub = BeamTargetSetup(
                comp.species_id,
                comp.kinetic_energy_gev,
                setup.target_id,
                setup.target_kinetic_energy_gev,
                comp.fraction * setup.beam_fraction,
                setup.collision_mode,
            )
            s_weighted += comp.fraction * collision_kinematics(sub).s_gev2
        sqrt_s = math.sqrt(max(s_weighted, 0.0))
        t_cm_mev = max(sqrt_s * 1e3 / 2.0, 1e-6)
        xi = lean.xi_from_T_MeV(t_cm_mev)
        sub0 = collision_kinematics(
            BeamTargetSetup(
                setup.beam_mix[0].species_id,
                setup.beam_mix[0].kinetic_energy_gev,
                setup.target_id,
                setup.target_kinetic_energy_gev,
                collision_mode=setup.collision_mode,
            )
        )
        return CollisionKinematics(
            sqrt_s_gev=sqrt_s,
            s_gev2=s_weighted,
            xi_collision=xi,
            beam_id=beam_id,
            target_id=target_id,
            beam_kinetic_gev=beam_e,
            target_kinetic_gev=target_e,
            cm_energy_gev=sqrt_s,
            beta_beam=sub0.beta_beam,
            beta_target=sub0.beta_target,
        )

    beam_id = setup.resolve_beam()
    target_id = setup.resolve_target()
    m1 = particle_mass_mev(beam_id) / 1000.0
    m2 = particle_mass_mev(target_id) / 1000.0
    E1 = m1 + max(setup.beam_kinetic_energy_gev, 0.0)
    E2 = m2 + max(setup.target_kinetic_energy_gev, 0.0)
    p1 = math.sqrt(max(E1 * E1 - m1 * m1, 0.0))
    p2 = math.sqrt(max(E2 * E2 - m2 * m2, 0.0))
    mode = setup.resolved_collision_mode()
    if mode == "fixed_target":
        s = m1 * m1 + m2 * m2 + 2.0 * m2 * E1
    else:
        # Head-on: beam momenta opposite along z.
        s = (E1 + E2) ** 2 - (p1 - p2) ** 2
    sqrt_s = math.sqrt(max(s, 0.0))
    beta1 = p1 / E1 if E1 > 0 else 0.0
    beta2 = p2 / E2 if E2 > 0 else 0.0
    t_cm_mev = max(sqrt_s * 1e3 / 2.0, 1e-6)
    xi = lean.xi_from_T_MeV(t_cm_mev)
    return CollisionKinematics(
        sqrt_s_gev=sqrt_s,
        s_gev2=s,
        xi_collision=xi,
        beam_id=beam_id,
        target_id=target_id,
        beam_kinetic_gev=setup.beam_kinetic_energy_gev,
        target_kinetic_gev=setup.target_kinetic_energy_gev,
        cm_energy_gev=sqrt_s,
        beta_beam=beta1,
        beta_target=beta2,
    )


def production_accessible(particle: HepParticle, kin: CollisionKinematics) -> bool:
    """Kinematic gate: produced state fits within CM energy budget."""
    return particle.mass_gev <= kin.accessible_mass_gev


def list_cern_accessible_particles(
    kin: CollisionKinematics,
    *,
    include_charm: bool = True,
    mass_xi: float | None = None,
) -> list[HepParticle]:
    """All catalog species kinematically accessible at this collision."""
    xi = mass_xi if mass_xi is not None else lean.XI_LOCKIN
    out: list[HepParticle] = []
    for sid in sorted(_catalog_index()):
        if not include_charm and any(
            f in sid for f in ("c", "b", "charm", "bottom", "jpsi", "psi")
        ):
            continue
        try:
            p = build_particle(sid, xi=xi)
        except KeyError:
            continue
        if production_accessible(p, kin):
            out.append(p)
    return out


def decay_modes_for(parent_id: str, *, xi: float = lean.XI_LOCKIN) -> list[HepDecayMode]:
    sid = hps.resolve_species_alias(parent_id)
    sid = BEAM_SPECIES.get(sid, sid)
    if sid in STABLE_SPECIES:
        return [
            HepDecayMode(
                parent_id=sid,
                channel="stable",
                daughter_ids=(),
                relative_branch=1.0,
            )
        ]

    modes: list[HepDecayMode] = []
    seen: set[str] = set()

    if hps.patch_decay_capable(sid):
        parent_mass = particle_mass_mev(sid, xi=xi)

        def mass_of(did: str) -> float:
            return particle_mass_mev(did, xi=xi)

        for gm in mc.generate_multichannel_modes(
            sid,
            parent_mass_mev=parent_mass,
            mass_of=mass_of,
        ):
            if gm.key in seen:
                continue
            seen.add(gm.key)
            modes.append(
                HepDecayMode(
                    parent_id=gm.parent_id,
                    channel=gm.channel,
                    daughter_ids=gm.daughter_ids,
                    relative_branch=gm.relative_branch,
                )
            )
    return modes


def _strong_width_per_s(q_mev: float) -> float:
    if q_mev <= 0.0:
        return 0.0
    return q_mev / HBAR_MEV_S


def _quarkonium_hadronic_width_per_s(q_mev: float) -> float:
    """
    Narrow hadronic quarkonium width slot (many open light-hadron channels).

    Scales as ``(γ²/10³) · Q/ℏ`` rather than the broad-resonance ``Q/ℏ``.
    """
    if q_mev <= 0.0:
        return 0.0
    return _strong_width_per_s(q_mev) * (lean.GAMMA**2) / 1000.0


def _hidden_strangeness_vector_strong_width_per_s(parent_mass_mev: float) -> float:
    return hdr.certified_strong_discharge_width_per_s("phi", parent_mass_mev)


def _certified_strong_discharge_width_per_s(parent_id: str, parent_mass_mev: float) -> float:
    """Finite certified strong spanning set: one pole width; spine contacts set BR."""
    return hdr.certified_strong_discharge_width_per_s(parent_id, parent_mass_mev)


def _em_quarkonium_lepton_width_per_s(
    parent_mass_mev: float,
    lepton_mass_mev: float,
) -> float:
    """
    Vector quarkonium → ℓ⁺ℓ⁻ (Lean chiral overlap × α² m³ slot).

    Γ ∝ chiralPseudoscalarFactor · α² · m_parent³ · (1 − m_ℓ²/m_parent²).
    """
    if parent_mass_mev <= lepton_mass_mev:
        return 0.0
    m = parent_mass_mev / 1000.0
    m_l = lepton_mass_mev / 1000.0
    alpha = _EM_FINE_STRUCTURE_ALPHA
    beta = max(1.0 - (m_l / m) ** 2, 0.0)
    chiral = hdr.CHIRAL_PSEUDOSCALAR_FACTOR
    contact = hdr.hidden_quarkonium_em_contact_factor()
    gamma_gev = (
        contact
        * chiral
        * alpha**2
        * m**3
        * beta
        * (1.0 + lean.GAMMA / 4.0)
        / (4.0 * math.pi**2)
    )
    return gamma_gev / dc.dbi.HBAR_GEV_S


def _em_radiative_quarkonium_width_per_s(parent_mass_mev: float) -> float:
    """V → γ + light (single-photon slot): Γ ∝ α · chiral · m³."""
    m = parent_mass_mev / 1000.0
    alpha = _EM_FINE_STRUCTURE_ALPHA
    chiral = hdr.CHIRAL_PSEUDOSCALAR_FACTOR
    gamma_gev = alpha * chiral * m**3 * (1.0 + lean.GAMMA / 6.0) / (16.0 * math.pi)
    return gamma_gev / dc.dbi.HBAR_GEV_S


def _pion_decay_constant_mev(hadron_mass_mev: float) -> float:
    """Chiral f_π = m_π √hadronIntrinsicScale (Lean HadronMassReadout)."""
    return hadron_mass_mev * PION_DECAY_CONSTANT_RATIO


def _cabibbo_v_us_squared() -> float:
    return hdr.ckm_slot_us_squared()


def _cabibbo_v_cd_squared() -> float:
    return hdr.ckm_slot_cd_squared()


def _cabibbo_v_cb_squared() -> float:
    return hdr.ckm_slot_cb_squared()


def _muon_weak_width_per_s(muon_mass_mev: float, *, env: ExperimentEnvironment) -> float:
    """μ± → e± ν ν̄ via Forces.G_F_from_beta five-body phase space (μ-e slot)."""
    m_mu = muon_mass_mev / 1000.0
    m_e = dc.dbi.model_electron_mass_mev() / 1000.0
    if m_mu <= m_e:
        return 0.0
    g_f = dc.dbi.g_f_from_forces_gev2()
    beta = max(1.0 - (m_e / m_mu) ** 2, 0.0)
    gamma_gev = g_f**2 * m_mu**5 * beta**2 / (192.0 * math.pi**3)
    width = gamma_gev / dc.dbi.HBAR_GEV_S
    return width * env.weak_width_factor() / max(env.outside_support_factor(), 1e-30)


def _baryon_pseudoscalar_weak_width_per_s(
    parent_mass_mev: float,
    baryon_mass_mev: float,
    meson_mass_mev: float,
    *,
    v_ckm2: float,
    env: ExperimentEnvironment,
) -> float:
    """Λ → p π and octet weak decays: charged-current baryon–pseudoscalar phase space."""
    nu = stability_neutrino_mass_mev()
    bridge = weak_bridge.weak_bridge_energy_mev(nu)
    q = parent_mass_mev - baryon_mass_mev - meson_mass_mev - bridge
    if q <= 0.0:
        return 0.0
    q_gev = q / 1000.0
    m_b_gev = parent_mass_mev / 1000.0
    m_meson_gev = meson_mass_mev / 1000.0
    f_pi = _pion_decay_constant_mev(meson_mass_mev) / 1000.0
    g_f = dc.dbi.g_f_from_forces_gev2()
    chiral = max(1.0 - (m_meson_gev / m_b_gev) ** 2, 0.0) ** 2
    # Baryon weak slot: G_F² |V|² f_π² m_B³ Q (1−m_π²/m_B²)² with Beltrami dressing.
    gamma_gev = (
        g_f**2
        * v_ckm2
        * f_pi**2
        * m_b_gev**3
        * q_gev
        * chiral
        * (1.0 + lean.GAMMA / 2.0)
        / (4.0 * math.pi**2)
    )
    width = gamma_gev / dc.dbi.HBAR_GEV_S
    return width * env.weak_width_factor() / max(env.outside_support_factor(), 1e-30)


def _two_body_pseudoscalar_weak_width_per_s(
    parent_mass_mev: float,
    lepton_mass_mev: float,
    *,
    v_ckm2: float,
    env: ExperimentEnvironment,
) -> float:
    """
    π± → ℓ± ν (and similar) via Forces.G_F_from_beta + chiral f_π.

    Γ = G_F² |V|² f_π² m_ℓ² m_π (1 − m_ℓ²/m_π²)² / (4π).
    """
    if parent_mass_mev <= lepton_mass_mev or lepton_mass_mev < 0.0:
        return 0.0
    m_h = parent_mass_mev / 1000.0
    m_l = lepton_mass_mev / 1000.0
    f_pi = _pion_decay_constant_mev(parent_mass_mev) / 1000.0
    beta = max(1.0 - (m_l / m_h) ** 2, 0.0)
    g_f = dc.dbi.g_f_from_forces_gev2()
    gamma_gev = g_f**2 * v_ckm2 * f_pi**2 * m_l**2 * m_h * beta**2 / (4.0 * math.pi)
    width = gamma_gev / dc.dbi.HBAR_GEV_S
    return width * env.weak_width_factor() / max(env.outside_support_factor(), 1e-30)


def _semileptonic_pseudoscalar_weak_width_per_s(
    parent_mass_mev: float,
    pion_mass_mev: float,
    *,
    v_ckm2: float,
    env: ExperimentEnvironment,
) -> float:
    """K± → π ℓ± ν̄ with m_ℓ → 0: two-body phase space with f_π at the pion pole."""
    if parent_mass_mev <= pion_mass_mev:
        return 0.0
    m_k = parent_mass_mev / 1000.0
    m_pi = pion_mass_mev / 1000.0
    f_pi = _pion_decay_constant_mev(pion_mass_mev) / 1000.0
    beta = max(1.0 - (m_pi / m_k) ** 2, 0.0)
    g_f = dc.dbi.g_f_from_forces_gev2()
    gamma_gev = g_f**2 * v_ckm2 * f_pi**2 * m_k * m_pi**2 * beta**2 / (8.0 * math.pi)
    width = gamma_gev / dc.dbi.HBAR_GEV_S
    return width * env.weak_width_factor() / max(env.outside_support_factor(), 1e-30)


def _open_charm_semileptonic_hadron_pole_mass_mev(parent_species_id: str) -> float:
    """Light-hadron pole anchoring the inclusive semileptonic tower."""
    if parent_species_id == "lambda_c":
        return particle_mass_mev("p", xi=lean.XI_LOCKIN)
    return particle_mass_mev("K_plus", xi=lean.XI_LOCKIN)


def _open_charm_semileptonic_weak_width_per_s(
    parent_mass_mev: float,
    lepton_mass_mev: float,
    *,
    parent_species_id: str,
    v_ckm2: float,
    env: ExperimentEnvironment,
) -> float:
    """
    Open-charm semileptonic on the shared light-hadron pole ($D\\to K\\ell\\nu$,
    $\\Lambda_c\\to p\\ell\\nu$ representatives).
    """
    hadron_pole = _open_charm_semileptonic_hadron_pole_mass_mev(parent_species_id)
    w_had = _semileptonic_pseudoscalar_weak_width_per_s(
        parent_mass_mev,
        hadron_pole,
        v_ckm2=v_ckm2,
        env=env,
    )
    mu_mass = particle_mass_mev("mu_plus", xi=lean.XI_LOCKIN)
    w_mu = _kaon_leptonic_weak_width_per_s(
        parent_mass_mev, mu_mass, v_ckm2=v_ckm2, env=env
    )
    w_l = _kaon_leptonic_weak_width_per_s(
        parent_mass_mev, lepton_mass_mev, v_ckm2=v_ckm2, env=env
    )
    if w_mu <= 0.0:
        return 0.0
    return w_had * (w_l / w_mu)


def _kaon_leptonic_weak_width_per_s(
    parent_mass_mev: float,
    lepton_mass_mev: float,
    *,
    v_ckm2: float,
    env: ExperimentEnvironment,
) -> float:
    """K± → ℓ± ν: two-body phase space with chiral f_K at the kaon pole."""
    if parent_mass_mev <= lepton_mass_mev:
        return 0.0
    m_k = parent_mass_mev / 1000.0
    m_l = lepton_mass_mev / 1000.0
    f_k = _pion_decay_constant_mev(parent_mass_mev) / 1000.0
    beta = max(1.0 - (m_l / m_k) ** 2, 0.0)
    g_f = dc.dbi.g_f_from_forces_gev2()
    gamma_gev = g_f**2 * v_ckm2 * f_k**2 * m_k * m_l**2 * beta**2 / (8.0 * math.pi)
    width = gamma_gev / dc.dbi.HBAR_GEV_S
    return width * env.weak_width_factor() / max(env.outside_support_factor(), 1e-30)


_LIGHT_WEAK_REFERENCE_DAUGHTERS: dict[str, tuple[str, ...]] = {}


def _light_weak_reference_daughters(parent_id: str) -> tuple[str, ...] | None:
    import hqiv_hep_patch_species as hps

    parent = hps.patch_from_species_id(parent_id)
    if parent is None:
        return None
    import hqiv_property_channels as pc

    return pc.certified_light_weak_kinematic_reference(parent)


def _visible_lepton_daughter(daughter_ids: tuple[str, ...]) -> bool:
    return any(d in ("mu_plus", "mu_minus", "e_plus", "e_minus") for d in daughter_ids)


def _light_weak_discharge_coupling(parent_mass_mev: float, daughter_ids: tuple[str, ...]) -> float:
    m_anchor = _witness_nucleon_mass_mev("p")
    if _visible_lepton_daughter(daughter_ids):
        return hdr.light_semileptonic_inside_discharge_coupling(parent_mass_mev, m_anchor)
    return hdr.light_hadronic_outside_discharge_coupling(parent_mass_mev, m_anchor)


def _light_weak_kinematic_slot(
    parent: HepParticle,
    daughter_ids: tuple[str, ...],
    *,
    env: ExperimentEnvironment,
) -> float:
    """Chiral weak phase-space ratio to the parent's certified reference outlet."""
    ref = _light_weak_reference_daughters(parent.species_id)
    if ref is None:
        return 1.0
    ref_parts = tuple(build_particle(d, xi=parent.xi) for d in ref)
    cur_parts = tuple(build_particle(d, xi=parent.xi) for d in daughter_ids)
    w_ref = _hadronic_weak_width_per_s(parent, ref_parts, env=env)
    w_cur = _hadronic_weak_width_per_s(parent, cur_parts, env=env)
    if w_ref <= 0.0 or not math.isfinite(w_ref):
        return 1.0
    return max(w_cur / w_ref, 1e-12)


def _light_weak_discharge_width_per_s(parent: HepParticle, *, env: ExperimentEnvironment) -> float:
    """
    Certified light weak pole width: pion μ anchor × mass rung × light collider/outside dressing.

    Branching within the finite spanning set uses spine × kinematic × inside/outside coupling.
    """
    m_anchor = _witness_nucleon_mass_mev("p")
    m_pi = _chiral_pseudoscalar_mass_mev("pi_plus", xi=parent.xi)
    if m_pi is None or m_pi <= 0.0:
        return 0.0
    m_mu = SPECIAL_MASSES_MEV["mu_plus"]
    w_pi = _two_body_pseudoscalar_weak_width_per_s(
        m_pi,
        m_mu,
        v_ckm2=dc.dbi.V_UD**2,
        env=env,
    )
    coll = hdr.light_collider_curvature_width_factor(
        parent.mass_mev,
        m_anchor,
        env.magnetic_field_tesla,
        env.collider_reference_tesla,
        env.comoving_stream_fraction,
        weak_bridge_shape=weak_bridge.weak_bridge_shape(),
    )
    outside = max(env.outside_support_factor(), 1e-30)
    mass_release = hdr.light_weak_pole_width_mass_factor(
        parent.mass_mev, m_pi, m_anchor
    )
    return w_pi * mass_release * coll / (outside ** lean.GAMMA)


def _light_weak_topology_weight(
    parent: HepParticle,
    mode: HepDecayMode,
    *,
    q_mev: float,
    spine_prior: float,
    env: ExperimentEnvironment,
) -> float:
    daughters = tuple(mode.daughter_ids)
    kin = _light_weak_kinematic_slot(parent, daughters, env=env)
    coup = _light_weak_discharge_coupling(parent.mass_mev, daughters)
    ps = hpr.phase_space_q_weight(q_mev, parent.mass_mev, len(daughters))
    return max(spine_prior, 1e-12) * kin * coup * max(ps, 1e-6)


def _weak_width_daughters_by_patch(
    daughters: tuple[HepParticle, ...],
    *,
    meson_pred,
    baryon_pred,
) -> tuple[list[HepParticle], list[HepParticle]]:
    """Partition daughters by ``HadronPatch`` discharge predicates (not species-id tables)."""
    mesons: list[HepParticle] = []
    baryons: list[HepParticle] = []
    for d in daughters:
        patch = hps.daughter_patch(d.species_id)
        if patch is None:
            continue
        if meson_pred(patch):
            mesons.append(d)
        elif baryon_pred(patch):
            baryons.append(d)
    return mesons, baryons


def _hadronic_weak_width_per_s(
    parent: HepParticle,
    daughters: tuple[HepParticle, ...],
    *,
    env: ExperimentEnvironment,
) -> float:
    """Route charged-current hadronic weak decays to the correct phase-space slot."""
    if parent.species_id in ("mu_plus", "mu_minus"):
        return _muon_weak_width_per_s(parent.mass_mev, env=env)

    parent_patch = hps.patch_from_species_id(parent.species_id)

    lepton_ids = {"e+", "e-", "mu+", "mu-", "mu_plus", "mu_minus"}
    leptons = [d for d in daughters if d.species_id in lepton_ids]
    if leptons:
        m_l = max(d.mass_mev for d in leptons)
        if parent_patch is not None and parent_patch.is_light_kaon:
            return _kaon_leptonic_weak_width_per_s(
                parent.mass_mev,
                m_l,
                v_ckm2=_cabibbo_v_us_squared(),
                env=env,
            )
        if parent_patch is not None and (
            parent_patch.is_open_charm_meson_nonstrange
            or (
                parent_patch.is_open_charm_baryon_ground
                and parent_patch.nominal_id == "lambda_c"
            )
        ):
            return _open_charm_semileptonic_weak_width_per_s(
                parent.mass_mev,
                m_l,
                parent_species_id=parent.species_id,
                v_ckm2=_cabibbo_v_cd_squared(),
                env=env,
            )
        v2 = dc.dbi.V_UD**2
        return _two_body_pseudoscalar_weak_width_per_s(
            parent.mass_mev,
            m_l,
            v_ckm2=v2,
            env=env,
        )

    def _light_meson(p: hps.HadronPatch) -> bool:
        return hps.is_light_hadron_meson_patch(p) or p.is_light_vector_meson

    def _light_baryon(p: hps.HadronPatch) -> bool:
        return hps.is_light_baryon_discharge_patch(p)

    mesons, baryons = _weak_width_daughters_by_patch(
        daughters, meson_pred=_light_meson, baryon_pred=_light_baryon
    )
    open_charm_mesons = [
        d
        for d in daughters
        if (p := hps.daughter_patch(d.species_id)) is not None and p.is_open_charm and p.is_meson
    ]

    if parent_patch is not None and (
        parent_patch.is_open_charm_meson_nonstrange
        or parent_patch.is_open_charm_strange_meson
        or parent_patch.is_open_bottom_meson_nonstrange
        or parent_patch.is_open_bottom_meson_strange
    ):
        pions = [
            d
            for d in mesons
            if (p := hps.daughter_patch(d.species_id)) is not None
            and (hps.is_pion_discharge_patch(p) or (p.is_light_kaon and p.ledger.q3 == 0))
        ]
        kaons = [
            d
            for d in mesons
            if (p := hps.daughter_patch(d.species_id)) is not None and p.is_light_kaon
        ]
        if (
            parent_patch.is_open_bottom_meson_strange
            and len(daughters) == 2
            and mesons
            and not baryons
        ):
            phi_pole = particle_mass_mev("phi", xi=lean.XI_LOCKIN)
            return _semileptonic_pseudoscalar_weak_width_per_s(
                parent.mass_mev,
                phi_pole,
                v_ckm2=_cabibbo_v_cb_squared(),
                env=env,
            )
        if (
            parent_patch.is_open_bottom
            and open_charm_mesons
            and mesons
            and not baryons
        ):
            return _semileptonic_pseudoscalar_weak_width_per_s(
                parent.mass_mev,
                open_charm_mesons[0].mass_mev,
                v_ckm2=_cabibbo_v_cb_squared(),
                env=env,
            )
        if (
            parent_patch.is_open_charm_meson_nonstrange
            and len(daughters) == 2
            and kaons
            and not baryons
        ):
            return _semileptonic_pseudoscalar_weak_width_per_s(
                parent.mass_mev,
                kaons[0].mass_mev,
                v_ckm2=_cabibbo_v_cd_squared(),
                env=env,
            )
        if len(mesons) >= 2 and not baryons:
            q = parent.mass_mev - sum(d.mass_mev for d in daughters)
            base = _weak_width_per_s(q, env=env, residual_mev=max(q, 0.0))
            v2 = (
                _cabibbo_v_cb_squared()
                if parent_patch.is_open_bottom
                else _cabibbo_v_cd_squared()
            )
            return base * (v2 / max(dc.dbi.V_UD**2, 1e-30))
        if pions or kaons:
            v2 = (
                _cabibbo_v_cb_squared()
                if parent_patch.is_open_bottom
                else _cabibbo_v_cd_squared()
            )
            pole = pions[0].mass_mev if pions else (kaons[0].mass_mev if kaons else parent.mass_mev * 0.2)
            return _semileptonic_pseudoscalar_weak_width_per_s(
                parent.mass_mev,
                pole,
                v_ckm2=v2,
                env=env,
            )
    if (
        parent_patch is not None
        and (parent_patch.is_open_bottom_baryon or parent_patch.is_open_bottom_meson_nonstrange
             or parent_patch.is_open_bottom_meson_strange)
        and mesons
        and open_charm_mesons
    ):
        return _semileptonic_pseudoscalar_weak_width_per_s(
            parent.mass_mev,
            open_charm_mesons[0].mass_mev,
            v_ckm2=_cabibbo_v_cb_squared(),
            env=env,
        )
    if mesons and baryons:
        return _baryon_pseudoscalar_weak_width_per_s(
            parent.mass_mev,
            baryons[0].mass_mev,
            mesons[0].mass_mev,
            v_ckm2=dc.dbi.V_UD**2,
            env=env,
        )
    pions = [
        d
        for d in daughters
        if (p := hps.daughter_patch(d.species_id)) is not None and hps.is_pion_discharge_patch(p)
    ]
    if pions and parent_patch is not None and parent_patch.is_light_kaon:
        if len(daughters) == 1:
            return _semileptonic_pseudoscalar_weak_width_per_s(
                parent.mass_mev,
                pions[0].mass_mev,
                v_ckm2=_cabibbo_v_us_squared(),
                env=env,
            )
        q = parent.mass_mev - sum(d.mass_mev for d in daughters)
        return _weak_width_per_s(q, env=env, residual_mev=max(q, 0.0))
    if (
        parent_patch is not None
        and parent_patch.sector == "open_charm_baryon"
        and baryons
    ):
        if mesons:
            pole = mesons[0].mass_mev
        else:
            pole = _chiral_pseudoscalar_mass_mev("pi_plus", xi=lean.XI_LOCKIN)
            if pole is None:
                raise ValueError("chiral pion mass required for baryon weak width")
        return _baryon_pseudoscalar_weak_width_per_s(
            parent.mass_mev,
            baryons[0].mass_mev,
            pole,
            v_ckm2=_cabibbo_v_cd_squared(),
            env=env,
        )
    q = parent.mass_mev - sum(d.mass_mev for d in daughters)
    return _weak_width_per_s(q, env=env, residual_mev=max(q, 0.0))


def _weak_width_per_s(
    q_mev: float,
    *,
    env: ExperimentEnvironment,
    residual_mev: float | None = None,
) -> float:
    res = max(q_mev if residual_mev is None else residual_mev, 0.0)
    if res <= 0.0 or q_mev <= 0.0:
        return 0.0
    hl = dc.dbi.weak_beta_half_life_seconds(
        q_mev,
        res,
        A=1,
        bonded=False,
        local_curvature_width_factor=env.weak_width_factor(),
        lab_temperature_factor=env.outside_support_factor(),
    )
    if not math.isfinite(hl) or hl <= 0.0:
        return 0.0
    return math.log(2.0) / hl


def evaluate_hep_decay_edge(
    parent: HepParticle,
    mode: HepDecayMode,
    *,
    xi: float,
    env: ExperimentEnvironment,
) -> HepDecayEdge | None:
    if mode.channel == "stable":
        return None
    daughters: list[HepParticle] = []
    for did in mode.daughter_ids:
        try:
            daughters.append(build_particle(did, xi=xi))
        except KeyError:
            return None
    m_daughters = sum(d.mass_mev for d in daughters)
    bridge = 0.0
    if mode.channel in ("weak", "weak_hadron"):
        nu = stability_neutrino_mass_mev()
        bridge = weak_bridge.weak_bridge_energy_mev(nu)
    q = parent.mass_mev - m_daughters - bridge
    channel_open = q > 0.0

    if mode.channel == "strong":
        import hqiv_hep_decay_certificates as cert

        if parent.species_id in hpr.HIDDEN_QUARKONIA:
            width = _quarkonium_hadronic_width_per_s(q) if channel_open else 0.0
        elif cert.is_certified_strong_discharge_parent_id(parent.species_id):
            width = (
                _certified_strong_discharge_width_per_s(parent.species_id, parent.mass_mev)
                if channel_open
                else 0.0
            )
        else:
            width = _strong_width_per_s(q) if channel_open else 0.0
        emitted = tuple(f"hadron_{d.species_id}" for d in daughters)
    elif mode.channel == "electromagnetic":
        lepton_ids = {"e+", "e-", "mu+", "mu-", "mu_plus", "mu_minus", "e_plus", "e_minus"}
        leptons = [d for d in daughters if d.species_id in lepton_ids]
        if len(daughters) == 1 and daughters[0].species_id == "gamma":
            width = _strong_width_per_s(q) * 1e-4 if channel_open else 0.0
            emitted = ("gamma",)
        elif any(d.species_id == "gamma" for d in daughters) and parent.species_id in hpr.HIDDEN_QUARKONIA:
            width = (
                _em_radiative_quarkonium_width_per_s(parent.mass_mev)
                * max(1.0 - (sum(d.mass_mev for d in daughters if d.species_id != "gamma") / parent.mass_mev), 0.1)
                if channel_open
                else 0.0
            )
            emitted = tuple(d.species_id for d in daughters)
        elif leptons and parent.species_id in hpr.HIDDEN_QUARKONIA:
            width = _em_quarkonium_lepton_width_per_s(
                parent.mass_mev,
                leptons[0].mass_mev,
            )
            emitted = tuple(d.species_id for d in leptons)
        else:
            width = _strong_width_per_s(q) * 1e-3 if channel_open else 0.0
            emitted = tuple(d.species_id for d in leptons) if leptons else ("gamma",)
    else:
        import hqiv_hep_decay_certificates as cert

        if cert.is_light_weak_discharge_parent_id(parent.species_id):
            width = (
                _light_weak_discharge_width_per_s(parent, env=env)
                if channel_open
                else 0.0
            )
        else:
            width = (
                _hadronic_weak_width_per_s(parent, tuple(daughters), env=env)
                if channel_open
                else 0.0
            )
        emitted = tuple(
            list(d.species_id for d in daughters) + ["nu_e", "nu_e_bar"][: 1 if "weak" else 0]
        )

    width *= hdr.gauge_curvature_width_factor(
        parent.species_id,
        mode.channel,
        tuple(d.species_id for d in daughters),
    )

    half_life = math.inf if width <= 0.0 else math.log(2.0) / width
    return HepDecayEdge(
        parent=parent,
        daughters=tuple(daughters),
        mode=mode,
        q_mev=q,
        width_per_s=width,
        half_life_s=half_life,
        branching_ratio=0.0,
        channel_open=channel_open,
        emitted=emitted,
    )


def stability_neutrino_mass_mev() -> float:
    import hqiv_isotope_stability_halflife as ish

    return ish.model_electron_neutrino_mass_mev()


def _nuclear_bridge_edges(
    parent: HepParticle,
    *,
    env: ExperimentEnvironment,
) -> list[HepDecayEdge]:
    """Wire free-neutron (and light nuclear) β decay from ``hqiv_decay_chain``."""
    if parent.species_id != "n":
        return []
    state = dc.NuclearState(1, 0, xi=parent.xi, label="n")
    n_edges = dc.edges_from_nuclear_state(
        state,
        q_policy="nucleon_gap",
        residual_mode="effective",
    )
    out: list[HepDecayEdge] = []
    for ne in n_edges:
        if ne.daughter is None or not ne.channel.channel_open:
            continue
        daughter_p = build_particle("p", xi=parent.xi)
        mode = HepDecayMode(
            parent_id="n",
            channel="weak",
            daughter_ids=("p",),
            relative_branch=ne.branching_ratio,
        )
        out.append(
            HepDecayEdge(
                parent=parent,
                daughters=(daughter_p,),
                mode=mode,
                q_mev=ne.channel.endpoint_q_mev,
                width_per_s=ne.channel.width_per_s,
                half_life_s=ne.channel.half_life_s,
                branching_ratio=ne.branching_ratio,
                channel_open=True,
                emitted=ne.channel.emitted,
            )
        )
    return out


def _pool_quarkonium_partial_widths(
    parent: HepParticle,
    weighted: list[tuple[HepDecayEdge, float, float]],
) -> list[tuple[HepDecayEdge, float, float]]:
    """
    Pool hadronic + radiative-hadronic quarkonium width into one Γ_had slot.

    Leptonic EM (ee, μμ) partial widths stay per-channel.
    """
    if parent.species_id not in hpr.HIDDEN_QUARKONIA:
        return weighted
    hadronic: list[tuple[HepDecayEdge, float, float]] = []
    leptonic_em: list[tuple[HepDecayEdge, float, float]] = []
    for item in weighted:
        edge = item[0]
        if edge.mode.channel == "electromagnetic":
            dids = edge.mode.daughter_ids
            if any(d in ("e_plus", "e_minus", "mu_plus", "mu_minus") for d in dids):
                leptonic_em.append(item)
            else:
                hadronic.append(item)
        else:
            hadronic.append(item)
    if not hadronic:
        return weighted
    q_max = max(e.q_mev for e, _, _ in hadronic)
    gamma_had = _quarkonium_hadronic_width_per_s(q_max)
    prior_sum = sum(tw for _, _, tw in hadronic)
    if prior_sum <= 0.0:
        return weighted
    pooled_had = [
        (edge, gamma_had * tw / prior_sum, tw) for edge, _, tw in hadronic
    ]
    return pooled_had + leptonic_em


def edges_from_particle(
    parent: HepParticle,
    *,
    env: ExperimentEnvironment,
) -> list[HepDecayEdge]:
    nuclear = _nuclear_bridge_edges(parent, env=env)
    if nuclear:
        return nuclear

    modes = decay_modes_for(parent.species_id, xi=parent.xi)
    policy = hpr.branching_policy_for(parent.species_id)
    weighted: list[tuple[HepDecayEdge, float, float]] = []
    for mode in modes:
        edge = evaluate_hep_decay_edge(parent, mode, xi=parent.xi, env=env)
        if edge is None or not edge.channel_open:
            continue
        tw = hpr.channel_topology_weight(
            parent_id=parent.species_id,
            channel=mode.channel,
            q_mev=edge.q_mev,
            parent_mass_mev=parent.mass_mev,
            n_daughters=len(mode.daughter_ids),
            relative_prior=mode.relative_branch,
            daughter_ids=mode.daughter_ids,
        )
        import hqiv_hep_decay_certificates as cert

        if cert.is_light_weak_discharge_parent_id(parent.species_id) and mode.channel == "weak":
            tw = _light_weak_topology_weight(
                parent,
                mode,
                q_mev=edge.q_mev,
                spine_prior=mode.relative_branch,
                env=env,
            )
        weighted.append((edge, edge.width_per_s, tw))
    if not weighted:
        return []
    weighted = _pool_quarkonium_partial_widths(parent, weighted)
    brs = hpr.normalize_branching_ratios(
        [(w, tw) for _, w, tw in weighted],
        policy=policy,
    )
    out: list[HepDecayEdge] = []
    for (edge, width, _), br in zip(weighted, brs):
        hl = math.inf if width <= 0.0 else math.log(2.0) / width
        out.append(
            HepDecayEdge(
                parent=edge.parent,
                daughters=edge.daughters,
                mode=edge.mode,
                q_mev=edge.q_mev,
                width_per_s=width,
                half_life_s=hl,
                branching_ratio=br,
                channel_open=edge.channel_open,
                emitted=edge.emitted,
            )
        )
    return out


ChainFollow = Literal["heaviest", "all_hadronic"]


def expand_hep_chain(
    root: HepParticle,
    *,
    env: ExperimentEnvironment,
    max_depth: int = 8,
    min_branch: float = 1e-6,
    follow: ChainFollow = "heaviest",
) -> tuple[HepDecayNode, list[HepDecayNode], list[HepDecayNode]]:
    root_node = HepDecayNode(
        particle=root,
        depth=0,
        cumulative_weight=1.0,
        cumulative_time_s=0.0,
    )
    all_nodes: list[HepDecayNode] = [root_node]
    terminal: list[HepDecayNode] = []
    frontier: list[HepDecayNode] = [root_node]

    while frontier:
        node = frontier.pop(0)
        if node.depth >= max_depth:
            terminal.append(node)
            continue
        edges = edges_from_particle(node.particle, env=env)
        open_edges = [e for e in edges if e.branching_ratio >= min_branch]
        if not open_edges:
            terminal.append(node)
            continue
        for edge in open_edges:
            hadronic = [
                d
                for d in edge.daughters
                if d.species_id
                not in ("gamma", "e+", "e-", "mu+", "mu-", "mu_plus", "mu_minus")
            ]
            if not hadronic:
                terminal.append(node)
                continue
            targets = (
                hadronic
                if follow == "all_hadronic"
                else [max(hadronic, key=lambda d: d.mass_mev)]
            )
            for daughter in targets:
                w = node.cumulative_weight * edge.branching_ratio
                if follow == "all_hadronic":
                    w /= max(len(hadronic), 1)
                if w < min_branch:
                    continue
                dt = edge.half_life_s if math.isfinite(edge.half_life_s) else 0.0
                child = HepDecayNode(
                    particle=daughter,
                    depth=node.depth + 1,
                    cumulative_weight=w,
                    cumulative_time_s=node.cumulative_time_s + dt,
                    via=edge,
                )
                node.children.append(child)
                all_nodes.append(child)
                if child.depth < max_depth and (
                    decay_modes_for(daughter.species_id)
                    or daughter.species_id == "n"
                ):
                    frontier.append(child)
                else:
                    terminal.append(child)
    return root_node, all_nodes, terminal


def run_experiment(
    setup: BeamTargetSetup,
    *,
    env: ExperimentEnvironment | None = None,
    production_ids: list[str] | None = None,
    max_depth: int = 6,
    min_branch: float = 1e-5,
    follow: ChainFollow = "heaviest",
    include_beam_dump: bool = False,
    include_heavy: bool = False,
) -> HepDecayChainResult:
    env = env or ExperimentEnvironment()
    kin = collision_kinematics(setup)
    mass_xi = lean.XI_LOCKIN

    if production_ids:
        produced = [build_particle(pid, xi=mass_xi) for pid in production_ids]
    else:
        produced = list_cern_accessible_particles(kin, mass_xi=mass_xi, include_charm=True)

    roots: list[HepDecayNode] = []
    all_nodes: list[HepDecayNode] = []
    terminal: list[HepDecayNode] = []

    default_roots = ("delta_p", "rho_zero", "K_plus", "lambda", "phi")
    beam_dump_roots = ("n", "lambda", "K_plus", "pi_plus")
    heavy_roots = ("Jpsi", "D_plus", "lambda_c", "B_plus", "lambda_b", "Upsilon")
    auto_heavy = include_heavy or kin.sqrt_s_gev >= 500.0

    if production_ids:
        seeds = production_ids
    elif include_beam_dump:
        seeds = list(beam_dump_roots)
    elif auto_heavy:
        seeds = list(heavy_roots) + list(default_roots)
    else:
        seeds = [p.species_id for p in produced if p.species_id in default_roots]
    for sid in seeds:
        try:
            root_p = build_particle(sid, xi=mass_xi)
        except KeyError:
            continue
        if not production_accessible(root_p, kin):
            continue
        rnode, nodes, terms = expand_hep_chain(
            root_p,
            env=env,
            max_depth=max_depth,
            min_branch=min_branch,
            follow=follow,
        )
        roots.append(rnode)
        all_nodes.extend(nodes)
        terminal.extend(terms)

    new_species: list[tuple[str, float]] = []
    for sid in sorted(hpr.NEW_STATE_IDS):
        try:
            new_species.append((sid, particle_mass_mev(sid, xi=mass_xi)))
        except KeyError:
            continue
    prod_rates = hpr.production_rate_table(
        new_species,
        sqrt_s_gev=kin.sqrt_s_gev,
        accessible_mass_gev=kin.accessible_mass_gev,
        collision_mode=setup.resolved_collision_mode(),
    )

    return HepDecayChainResult(
        setup=setup,
        kinematics=kin,
        environment=env,
        produced=tuple(produced),
        root_nodes=tuple(roots),
        all_nodes=tuple(all_nodes),
        terminal=tuple(terminal),
        production_rates=tuple(prod_rates),
    )


# --- Facility presets ---
FACILITY_PRESETS: dict[str, BeamTargetSetup] = {
    "LHC_pp_13TeV": BeamTargetSetup("p", 6500.0, "p", 6500.0),
    "LHC_pp_7TeV": BeamTargetSetup("p", 3500.0, "p", 3500.0),
    "SPS_p_beam_400GeV": BeamTargetSetup("p", 400.0, "p", 0.0),
    "PS_p_24GeV": BeamTargetSetup("p", 24.0, "p", 0.0),
    "NA62_K_75GeV": BeamTargetSetup("K+", 75.0, "p", 0.0),
    "COMPASS_muon_160GeV": BeamTargetSetup("mu-", 160.0, "p", 0.0),
    "PS_p_beam_dump_24GeV": BeamTargetSetup("p", 24.0, "p", 0.0),
    "Belle2_Upsilon4S": BeamTargetSetup("e+", 5.29, "e-", 5.29),
    "Belle2_HQIV_Upsilon_on_shell": BeamTargetSetup("e+", 4.59, "e-", 4.59),
    "LHCb_pp_13TeV": BeamTargetSetup("p", 6500.0, "p", 6500.0),
}


def refresh_dynamic_facility_presets() -> None:
    """HQIV witness facilities: beam energy follows ladder mass (not PDG tables)."""
    try:
        e_gev = particle_mass_mev("Upsilon") / 2000.0
        FACILITY_PRESETS["Belle2_HQIV_Upsilon_on_shell"] = BeamTargetSetup(
            "e+", e_gev, "e-", e_gev
        )
    except KeyError:
        pass


refresh_dynamic_facility_presets()


def _serialize_particle(p: HepParticle) -> dict:
    return {
        "species_id": p.species_id,
        "label": p.label,
        "mass_mev": p.mass_mev,
        "mass_sigma_mev": hsig.predicted_mass_sigma_mev(p.species_id, xi=p.xi),
        "xi": p.xi,
        "structure": p.structure,
        "pdg_name": p.pdg_name,
        "cern_accessible": p.cern_accessible,
    }


def _serialize_edge(e: HepDecayEdge) -> dict:
    parent_sig = hsig.predicted_mass_sigma_mev(e.parent.species_id, xi=e.parent.xi)
    daughter_sigs = [
        hsig.predicted_mass_sigma_mev(d.species_id, xi=d.xi) for d in e.daughters
    ]
    q_sig = hsig.q_sigma_mev(parent_sig, daughter_sigs)
    return {
        "parent": e.parent.species_id,
        "daughters": [d.species_id for d in e.daughters],
        "channel": e.mode.channel,
        "q_mev": e.q_mev,
        "q_sigma_mev": q_sig,
        "width_per_s": e.width_per_s,
        "width_sigma_per_s": hsig.width_sigma_from_q(q_sig),
        "half_life_s": e.half_life_s if math.isfinite(e.half_life_s) else None,
        "half_life_sigma_s": (
            hsig.half_life_sigma_from_width(
                e.width_per_s, hsig.width_sigma_from_q(q_sig)
            )
            if e.width_per_s > 0
            else None
        ),
        "branching_ratio": e.branching_ratio,
        "emitted": list(e.emitted),
    }


def _serialize_node(n: HepDecayNode) -> dict:
    out: dict = {
        "particle": _serialize_particle(n.particle),
        "depth": n.depth,
        "cumulative_weight": n.cumulative_weight,
        "cumulative_time_s": n.cumulative_time_s,
        "children": [_serialize_node(c) for c in n.children],
    }
    if n.via is not None:
        out["via"] = _serialize_edge(n.via)
    return out


def build_payload(result: HepDecayChainResult) -> dict:
    return {
        "source": "scripts/hqiv_hep_decay_chain.py",
        "lean_modules": [
            "Hqiv.Physics.HepDecayReadout",
            "Hqiv.Physics.TuftGlobalHadronReadout",
            "Hqiv.Physics.HadronMassReadout",
            "Hqiv.Physics.WeakFanoHopfBridge",
            "Hqiv.Physics.NuclearAndAtomicSpectra",
            "Hqiv.Physics.Forces",
        ],
        "multichannel_expansion": "scripts/hqiv_hep_multichannel_expansion.py",
        "collision": {
            "beam_id": result.setup.beam_id,
            "beam_kinetic_gev": result.setup.beam_kinetic_energy_gev,
            "target_id": result.setup.target_id,
            "target_kinetic_gev": result.setup.target_kinetic_energy_gev,
            "beam_fraction": result.setup.beam_fraction,
            "collision_mode": result.setup.resolved_collision_mode(),
            "beam_mix": [
                {
                    "species_id": c.species_id,
                    "kinetic_gev": c.kinetic_energy_gev,
                    "fraction": c.fraction,
                }
                for c in result.setup.beam_mix
            ],
            "sqrt_s_gev": result.kinematics.sqrt_s_gev,
            "xi_collision": result.kinematics.xi_collision,
            "accessible_mass_gev": result.kinematics.accessible_mass_gev,
        },
        "environment": {
            "magnetic_field_tesla": result.environment.magnetic_field_tesla,
            "collider_reference_tesla": result.environment.collider_reference_tesla,
            "comoving_stream_fraction": result.environment.comoving_stream_fraction,
            "lab_temperature_K": result.environment.lab_temperature_K,
            "gravity_tier": result.environment.gravity_tier,
            "trap_embedding": result.environment.trap_embedding,
            "weak_width_factor": result.environment.weak_width_factor(),
            "outside_support_factor": result.environment.outside_support_factor(),
        },
        "produced_count": len(result.produced),
        "produced_sample": [_serialize_particle(p) for p in result.produced[:40]],
        "production_rates": [
            {
                "species_id": r.species_id,
                "mass_mev": r.mass_mev,
                "rate_proxy": r.rate_proxy,
                "normalized_fraction": r.normalized_fraction,
                "accessible": r.accessible,
                "flavor_sector": r.flavor_sector,
            }
            for r in result.production_rates
        ],
        "decay_chains": [_serialize_node(r) for r in result.root_nodes],
    }


def print_report(result: HepDecayChainResult) -> None:
    k = result.kinematics
    print("HQIV HEP decay-chain readout")
    print("=" * 72)
    print(
        f"Beam {result.setup.beam_id} @ {result.setup.beam_kinetic_energy_gev:.4g} GeV  "
        f"×  Target {result.setup.target_id} @ {result.setup.target_kinetic_energy_gev:.4g} GeV"
    )
    print(
        f"sqrt(s) = {k.sqrt_s_gev:.4g} GeV   xi_collision = {k.xi_collision:.4g}   "
        f"B = {result.environment.magnetic_field_tesla:.4g} T"
    )
    print(f"Kinematically accessible species: {len(result.produced)}")
    for root in result.root_nodes:
        _print_hep_tree(root, indent=0)


def _print_hep_tree(node: HepDecayNode, indent: int = 0) -> None:
    p = node.particle
    line = (
        f"{' ' * indent}{p.label} ({p.species_id})  "
        f"w={node.cumulative_weight:.4e}  m={p.mass_mev:.2f} MeV"
    )
    if node.via is not None:
        v = node.via
        line += f"  <- {v.mode.channel}  BR={v.branching_ratio:.4f}  Q={v.q_mev:.2f} MeV"
    print(line)
    for c in node.children:
        _print_hep_tree(c, indent + 2)


def main() -> None:
    parser = argparse.ArgumentParser(description="HQIV HEP decay-chain calculator")
    parser.add_argument("--facility", choices=sorted(FACILITY_PRESETS), default=None)
    parser.add_argument("--beam", type=str, default="p")
    parser.add_argument("--beam-energy", type=float, default=None, help="GeV kinetic")
    parser.add_argument("--target", type=str, default="p")
    parser.add_argument("--target-energy", type=float, default=0.0, help="GeV kinetic")
    parser.add_argument("--beam-fraction", type=float, default=1.0)
    parser.add_argument(
        "--beam-mix",
        type=str,
        default=None,
        help="composition e.g. p:0.85,pi+:12@0.15 (optional @energy GeV per species)",
    )
    parser.add_argument(
        "--follow",
        choices=("heaviest", "all_hadronic"),
        default="heaviest",
        help="chain continuation: heaviest daughter vs all hadronic branches",
    )
    parser.add_argument(
        "--beam-dump",
        action="store_true",
        help="include secondary/beam-dump seeds (n, lambda, K, pi)",
    )
    parser.add_argument(
        "--heavy",
        action="store_true",
        help="include charm/bottom decay roots (J/ψ, D, Λ_c, B, Υ)",
    )
    parser.add_argument("--B-tesla", type=float, default=0.0, dest="b_tesla")
    parser.add_argument("--collider-reference-tesla", type=float, default=4.0)
    parser.add_argument("--comoving-stream-fraction", type=float, default=0.0)
    parser.add_argument("--temperature-K", type=float, default=293.15)
    parser.add_argument("--trap", action="store_true", help="UCN trap embedding (bottle mode)")
    parser.add_argument("--produce", type=str, default=None, help="comma-separated seed particles")
    parser.add_argument("--max-depth", type=int, default=5)
    parser.add_argument("--json-out", type=Path, default=DEFAULT_JSON)
    args = parser.parse_args()

    if args.facility:
        setup = FACILITY_PRESETS[args.facility]
    else:
        beam_e = args.beam_energy if args.beam_energy is not None else 400.0
        mix = parse_beam_mix(args.beam_mix, default_energy_gev=beam_e) if args.beam_mix else ()
        setup = BeamTargetSetup(
            args.beam,
            beam_e,
            args.target,
            args.target_energy,
            args.beam_fraction,
            beam_mix=mix,
        )

    env = ExperimentEnvironment(
        magnetic_field_tesla=args.b_tesla,
        collider_reference_tesla=args.collider_reference_tesla,
        comoving_stream_fraction=args.comoving_stream_fraction,
        lab_temperature_K=args.temperature_K,
        trap_embedding=args.trap,
    )
    production = args.produce.split(",") if args.produce else None
    result = run_experiment(
        setup,
        env=env,
        production_ids=production,
        max_depth=args.max_depth,
        follow=args.follow,
        include_beam_dump=args.beam_dump,
        include_heavy=args.heavy,
    )
    print_report(result)
    payload = build_payload(result)
    args.json_out.parent.mkdir(parents=True, exist_ok=True)
    args.json_out.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"\nWrote {args.json_out}")


if __name__ == "__main__":
    main()
