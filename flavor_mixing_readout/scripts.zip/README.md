# Flavor mixing export bundle

Run from repo root:

  python3 scripts/hqiv_flavor_mixing_export.py

Build Lean spine:

  lake build paper_flavor_mixing
